#ifndef avgP
    #define avgP
    #include <Arduino.h>
    #include "DHT.h" 
    float avgNhietDoP(int pin, int tt);
    float avgDoAmP(int pin, int tt);
#endif